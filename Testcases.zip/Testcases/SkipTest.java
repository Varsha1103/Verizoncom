package Testcases;

import org.testng.annotations.Test;

public class SkipTest {
	
	@Test
	void login()
	{
		System.out.println("Login");
		int  num=10/0;
	}
	
	@Test(dependsOnMethods="login")
	void logout()
	{
		System.out.println("Logout");
	}

}
