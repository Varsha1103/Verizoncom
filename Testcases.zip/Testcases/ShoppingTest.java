package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ShoppingTest {
	
	@Test
	void method1() throws InterruptedException
	{
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://www.amazon.in/");
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  driver.close();
	}
	
	@Test
	void method2() throws InterruptedException
	{
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("https://www.flipkart.com/");
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
	  driver.close();

}
}