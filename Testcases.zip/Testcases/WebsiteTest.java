package Testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class WebsiteTest {
	
	@BeforeSuite
	void beforeSuite() {
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	void afterSuite() {
		System.out.println("After Suite");
	}
	
	@BeforeTest
	void beforeTest() {
		System.out.println("Before Test 2");
	}
	
	@AfterTest
	void afterTest() {
		System.out.println("After Test 2");
	}
	
	@BeforeClass
	void beforeClass() {
		System.out.println("Before Class 2");
	}
	
	@AfterClass
	void afterClass() {
		System.out.println("After Class 2");
	}
	
	@BeforeMethod
	void beforeMethod() {
		System.out.println("Before Method 2");
	}
	
	@AfterMethod
	void afterMethod() {
		System.out.println("After Method 2");
	}
	@Parameters({"username"})
	@Test(groups="loginTest")//(enabled=false)
	void login(String u)
	{
		System.out.println("Website Login" +u);
	}

	@Test(dataProvider="getData")
	void logout(String username,String password)
	{
	
		System.out.println("Website Logout" +username+" "+password);

	}
	@DataProvider
	Object[][] getData()
	{
	Object[][]data=new Object[3][2];
	data[0][0]="user1";
	data[0][0]="pass1";
	data[0][0]="user2";
	data[0][0]="pass2";
	data[0][0]="user3";
	data[0][0]="pass3";
	return data;
}
}
	
	

