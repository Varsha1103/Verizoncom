package Testcases;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
//import org.testng.Assert;
import org.testng.annotations.Test;

public class MobileTest {

	@BeforeSuite
	void beforeSuite() {
		System.out.println("Before Suite");
	}
	
	@AfterSuite
	void afterSuite() {
		System.out.println("After Suite");
	}
	
	@BeforeTest
	void beforeTest() {
		System.out.println("Before Test 1");
	}
	
	@AfterTest
	void afterTest() {
		System.out.println("After Test 1");
	}
	
	@BeforeClass
	void beforeClass() {
		System.out.println("Before Class 1");
	}
	
	@AfterClass
	void afterClass() {
		System.out.println("After Class 1");
	}
	
	@BeforeMethod
	void beforeMethod() {
		System.out.println("Before Method 1");
	}
	
	@AfterMethod
	void afterMethod() {
		System.out.println("After Method 1");
	}
		@Test
		void login()
		{
			try {
			System.out.println("Mobile Login");
			//int num=10/0;
			//System.out.println(num);
			}
			catch(Exception ex)
			{
				System.out.println("There is an Exception");
			}
			
		}
		@Test
		void logout()
		{
			System.out.println("Hello");
			/*boolean result=false;
			SoftAssert soft=new SoftAssert();
			soft.assertTrue(result);
			System.out.println("Bye");
			soft.assertAll();*/
		}
	}


