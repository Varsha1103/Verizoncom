package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SeleniumTest {
	WebDriver driver;
	
	
	@BeforeMethod
	void setup() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		driver=new ChromeDriver();
		Thread.sleep(2000);
	}
	
	@Test
	void openUrl() throws InterruptedException
	{
		
		driver.get("https://www.makemytrip.com/flights/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	@AfterMethod
	void tearDown()
	{
		driver.close();
	}

}
