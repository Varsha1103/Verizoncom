package SeleniumD1.copy;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_FlightBooking {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.makemytrip.com/flights/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.elementFromPoint(0,0).click()");
		Thread.sleep(2000);
		driver.findElement(By.id("fromCity")).click();
		driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("pune");
		Thread.sleep(2000);
		driver.findElements(By.className("calc60")).get(0).click();
		driver.findElement(By.id("toCity")).click();
		driver.findElement(By.className("react-autosuggest__input--open")).sendKeys("chandighar");
		Thread.sleep(2000);
		driver.findElements(By.className("calc60")).get(0).click();	
	}

}
