package SeleniumD1.copy;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_RoomBooking {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.oyorooms.com/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.className("datePickerDesktop--home")).click();
		for (int num=1;num<=3;num++)
		{
			Thread.sleep(2000);
			driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		}
		
		//driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		//driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		//driver.findElement(By.className("DateRangePicker__PaginationArrowIcon--next")).click();
		/*List<WebElement>tags=driver.findElements(By.tagName("span"));
		for(int index=0;index<tags.size();index++)
		{
			if (index==39||index==40)
			{
				tags.get(index).click();
				if(index==40)
					break;
			}
		}*/
		
		Thread.sleep(2000);
		List<WebElement>dates=driver.findElements(By.className("DateRangePicker__DateLabel"));
		for(WebElement d:dates)
		{
			if(d.getText().equals("2")||d.getText().equals("3"))
			{
				d.click();
				if(d.getText().equals("3"))
					break;
					
			}
		}
	}

}
