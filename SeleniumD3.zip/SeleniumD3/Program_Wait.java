package SeleniumD3;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Program_Wait {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		driver.get("https://www.geeksforgeeks.org/");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		    .withTimeout(Duration.ofSeconds(30))
		    .pollingEvery(Duration.ofSeconds(5))
			.ignoring(NoSuchElementException.class);
		
		WebDriverWait wait1=new WebDriverWait(driver,Duration.ofSeconds(10));
		WebDriverWait wait2=new WebDriverWait(driver,Duration.ofSeconds(10));
		
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.linkText("Sign In")))).click();
		
		//driver.findElement(By.linkText("Sign In")).click();
		//driver.findElement(By.id("luser")).sendKeys("abc@gmail.com");
		//Thread.sleep(3000);
		//driver.findElement(By.id("password")).sendKeys("13234");
		//Thread.sleep(3000);
		
		wait1.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("luser")))).sendKeys("abc@gmail.com");
		wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.id("password")))).sendKeys("13234");
		wait2.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.xpath("//button[text()='Sign In']")))).click();
		//driver.findElement(By.xpath("//button[text()='Sign In']")).click();
		
	}
}
