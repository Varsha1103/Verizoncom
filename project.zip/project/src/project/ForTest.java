package project;

public class ForTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] name= {"Prem","jo","ki","ko"};
		
for(String s:name)
{
	System.out.println(s);

	}
	}

}
