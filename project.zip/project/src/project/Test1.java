package project;
class ForTest {
	{
		String name;
		void show()
		{
			System.out.println("My Name is"+name);
		}
	}
}


public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
