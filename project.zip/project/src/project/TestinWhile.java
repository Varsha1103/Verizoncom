package project;

public class TestinWhile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
			int i=1;
			
	do
	{
		i++;
		System.out.println(i);
		
	}while(i>=5);
	

	}

}
