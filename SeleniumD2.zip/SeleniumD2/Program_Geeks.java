package SeleniumD2;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_Geeks {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.geeksforgeeks.org/");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Sign In")).click();
		driver.findElement(By.id("luser")).sendKeys("abc@gmail.com");
		Thread.sleep(3000);
		driver.findElement(By.id("password")).sendKeys("13234");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[text()='Sign In']")).click();
		
	}

}
