package SeleniumD2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_AlertHandle {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("//*[text()='Click for JS Alert']")).click();
		Thread.sleep(3000);
		Alert alertWindow=driver.switchTo().alert();
		System.out.println(alertWindow.getText());
		alertWindow.accept();
		
		
		driver.findElement(By.xpath("//*[text()='Click for JS Confirm']")).click();
		Thread.sleep(3000);
		Alert confirmWindow=driver.switchTo().alert();
		System.out.println(confirmWindow.getText());
		confirmWindow.dismiss();
		
		
		driver.findElement(By.xpath("//*[text()='Click for JS Prompt']")).click();
		Thread.sleep(3000);
		Alert promptWindow=driver.switchTo().alert();
		System.out.println(promptWindow.getText());
		promptWindow.sendKeys("hello");
		promptWindow.accept();	
	}

}
