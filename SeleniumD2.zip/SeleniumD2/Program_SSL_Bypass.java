package SeleniumD2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Program_SSL_Bypass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		ChromeOptions option=new ChromeOptions();
		option.addArguments("--ignore-certificate-errors");
		WebDriver driver=new ChromeDriver(option);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		driver.navigate().to("https://engineerdiaries.com/home");
		
	}

}
