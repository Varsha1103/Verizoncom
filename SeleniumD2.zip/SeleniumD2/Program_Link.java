package SeleniumD2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Program_Link {

	public static void main(String[] args) throws InterruptedException, MalformedURLException, IOException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\DELL\\Desktop\\eclipse2\\Verizon\\src\\SeleniumD1\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/index.htm");
		Thread.sleep(3000);
		driver.manage().window().maximize();
		Thread.sleep(3000);
		WebElement footer=driver.findElement(By.tagName("footer"));
		List<WebElement>links=footer.findElements(By.tagName("a"));
		System.out.println(links.size());
		for(WebElement e:links)
		{
			System.out.print(e.getText()+" ");
			HttpURLConnection conn=(HttpURLConnection)new URL(e.getAttribute("href")).openConnection();
			conn.setRequestMethod("GET");
			conn.connect();
			conn.getResponseCode();
			if(conn.getResponseCode()==200)
			{
				System.out.println("Working");
			}
			else
			{
				System.out.println("Not Working");
			}
		}
	}

}
