package stepDefinitions;

public class PluginDefinition {
	
	

}
