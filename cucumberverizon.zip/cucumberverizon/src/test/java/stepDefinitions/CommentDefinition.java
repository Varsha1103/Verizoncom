package stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CommentDefinition {
	@When("user enters comment")
	public void user_enters_comment() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("comment must be posted")
	public void comment_must_be_posted() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	   
	}



