package stepDefinitions;

public class ServiceDefinition {

}
