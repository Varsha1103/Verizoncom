package stepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CatalogDefinition {
	@Given("user is on the Catalog API page")
	public void user_is_on_the_catalog_api_page() {
	    System.out.println("Given1");
	}
	@When("user wants to {string} api catalog")
	public void user_wants_to_api_catalog(String m1) {
		System.out.println("When1 " +m1);
	}
	@When("user wants to {string} api catalog {string}")
	public void user_wants_to_api_catalog(String m2, String id) {
		System.out.println("When2 " +m2+" "+id);
	}
	@Then("user can access the catalog")
	public void user_can_access_the_catalog() {
		System.out.println("Then1");
	}

}