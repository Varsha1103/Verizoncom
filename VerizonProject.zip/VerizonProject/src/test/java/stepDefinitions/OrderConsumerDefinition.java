package stepDefinitions;

public class OrderConsumerDefinition {

}
