package stepDefinitions;

public class EnterpriseCustomerDefinition {

}
