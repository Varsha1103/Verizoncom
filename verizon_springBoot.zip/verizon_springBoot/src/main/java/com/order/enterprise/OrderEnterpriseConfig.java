package com.order.enterprise;

public class OrderEnterpriseConfig {

}
