package com.order.consumer;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "BeanAnnotation")
public class OrderConsumerConfig {
	
	    @Bean
	    public Order employeeBean()
	    {
	    return new Order();
	    }
}
