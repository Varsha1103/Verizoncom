package com.enterprise.customer;

public class EnterpriseCustomer {

}
