package com.service;

public class ServiceConfig {

}
