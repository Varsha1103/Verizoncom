package catalog;

import java.util.ArrayList;

public class Catalog {
    private int userId;
	private String name;
	public Catalog(){}
	public int getUserId()
	{
		return this.userId;
	}
	public String getName()
	{
		return this.name;
	}	
	public Catalog(String name) {
		this.name=name;
	}
	public Catalog(String name,int id) {
		this.name=name;
		this.userId=id;
	}
	public void test()
	{
		
		System.out.println("Test Method");
	}
	public ArrayList<String>getCatalogList()
	{
		ArrayList<String> data=new ArrayList<String>();
		data.add("Clothes");
		data.add("Food");
		return data;
	}
}
