package config;

public class ServiceConfig {

}
